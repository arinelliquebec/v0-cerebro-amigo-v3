# Config do Claude Code — Cérebro Amigo V3

Pacote de configuração para o Claude Code trabalhar bem na migração de arquitetura do V3.

## O que tem aqui

```
CLAUDE.md                          # memória do projeto (carregada toda sessão)
.claude/skills/
  cerebro-architecture/SKILL.md    # topologia, decisões, mapa de rotas
  clinical-safety/SKILL.md         # guardrails clínicos, crise, LGPD
  dotnet-gateway/SKILL.md          # convenções do gateway .NET 10
  python-ai-services/
    SKILL.md                       # orchestrator/agents/notifier
    references/bedrock-client.md   # migração do LLM p/ Bedrock (código + IAM)
  nextjs-bff/SKILL.md              # web + BFF, cookies, PWA
```

## Como instalar

Copie ambos para a **raiz do monorepo** (onde fica o `.git`):

```bash
cp CLAUDE.md /caminho/do/cerebro-amigo-v3/
cp -r .claude /caminho/do/cerebro-amigo-v3/
```

Commite no repo — assim você e o Adonai compartilham a mesma config:

```bash
git add CLAUDE.md .claude/
git commit -m "chore: config do Claude Code (CLAUDE.md + skills do V3)"
```

Na próxima sessão, o Claude Code:
- lê o `CLAUDE.md` automaticamente (sempre);
- descobre as skills em `.claude/skills/` e carrega cada uma **sob demanda**, quando a tarefa casar com a descrição (progressive disclosure — não inflam o contexto à toa).

## Como funciona o carregamento

1. **Sempre em contexto:** `CLAUDE.md` + nome/descrição de cada skill (~100 palavras cada).
2. **Sob demanda:** o corpo de uma SKILL.md entra só quando a tarefa dispara aquela skill.
3. **Quando precisar:** `references/bedrock-client.md` é lido pela skill `python-ai-services` só na hora da migração do LLM.

## Manutenção

- Mantenha o `CLAUDE.md` enxuto; detalhe novo vai para a skill do domínio.
- Ao concluir uma decisão de arquitetura, grave um ADR em `docs/adrs/` (o CLAUDE.md pede isso).
- A fonte da verdade longa continua em `docs/CONTEXT.md`; as skills resumem o operacional.
- Se uma skill não estiver disparando quando deveria, deixe a descrição mais explícita ("use ao... mesmo que o usuário não diga...").
